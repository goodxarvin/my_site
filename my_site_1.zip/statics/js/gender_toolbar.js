$(document).ready(function () {
    $('#id_gender').select2({
        placeholder: "Select your gender",
        theme: "classic",
        width: '100%'
    });
});